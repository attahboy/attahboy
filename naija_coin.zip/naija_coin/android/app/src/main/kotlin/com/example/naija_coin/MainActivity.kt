package com.example.naija_coin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
