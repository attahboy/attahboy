
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:badges/badges.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

AppBar buildAppBar(context) {
  return AppBar(
    backgroundColor: Constants.kPrimaryColor.withOpacity(.03),
    elevation: 0,
    leading: IconButton(
      icon: Icon(
        Icons.menu,
        color: Constants.kPrimaryColor,
      ),
      onPressed: () {
      
      },
      color: Constants.kPrimaryColor.withOpacity(0.5),
    ),
    title: Text(
      "Dashboard",
      style: TextStyle(
        fontFamily: " ",
        color: Colors.black,
        fontSize: 18.0
      ),
      ),

    actions: [
      Badge(
      position: BadgePosition.topEnd(top: 0, end: 3),
      animationDuration: Duration(milliseconds: 300),
      animationType: BadgeAnimationType.slide,
      badgeContent: Text(
        "1",
        style: TextStyle(color: Colors.white),
      ),
      child: IconButton(icon: Icon(Icons.shopping_cart),color: Constants.kPrimaryColor, onPressed: () {
         // Navigator.push(context, MaterialPageRoute(builder: (context) => Cart()));
      },),
    ),
      IconButton(
        icon: Icon(Icons.settings),
        onPressed: () {
         // Navigator.push(context, MaterialPageRoute(builder: (context) => StudentAccount()));
        },
        color: Constants.kPrimaryColor,
      ),
    ],
  );
}


AppBar singleAppBar({String? title, context}) {
  return AppBar(
    backgroundColor: Constants.kPrimaryColor,
    elevation: 0,
    leading: IconButton(
      icon: Icon(
         Icons.arrow_back_ios,
         color: Colors.white,
      ),
      onPressed: () {
        Navigator.pop(context);
      },
      color: Constants.kPrimaryColor.withOpacity(0.5),
    ),
    title: Text(
      title!,
      style: TextStyle(
        fontFamily: " ",
        color: Colors.white,
        fontSize: 18.0
      ),
      ),
  );
}

AppBar exAppBar({String? title, context}) {
  return AppBar(
    backgroundColor: Constants.kPrimaryColor.withOpacity(.03),
    elevation: 0,
    leading: Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: IconButton(
        icon: Icon(
           Icons.close,
           size: 30,
        ),
        onPressed: () {
          Navigator.pop(context);
        },
        color: Constants.kPrimaryColor.withOpacity(0.5),
      ),
    ),
    title: Text(
      title!,
      style: TextStyle(
        fontFamily: " ",
        color: Colors.black54,
        fontSize: 18.0
      ),
      ),
  );
}

AppBar loginAppBar({String? title, context}) {
  return AppBar(
    backgroundColor: Constants.kPrimaryColor.withOpacity(.02),
    elevation: 0,
    leading: Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: IconButton(
        icon: Icon(
           Icons.close,
           size: 30,
        ),
        onPressed: () {
          Navigator.pop(context);
        },
        color: Constants.kPrimaryColor.withOpacity(0.5),
      ),
    ),
    title: Text(
      title!,
      style: TextStyle(
        fontFamily: " ",
        color: Colors.black54,
        fontSize: 18.0
      ),
      ),
  );
}


AppBar longAppBar({String? title, context}) {
  return AppBar(
    backgroundColor: Constants.kPrimaryColor,
    elevation: 0,
    leading: IconButton(
      icon: Icon(
        Icons.arrow_back_ios,
      ),
      onPressed: () {
       Navigator.pop(context);
      },
      color: Colors.white,
    ),
    title: Text(
      title!,
      style: TextStyle(
        fontFamily: " ",
        color: Colors.black54,
        fontSize: 18.0
      ),
      ),
  );
}




AppBar requestAppBar({String? title, context}) {
  return AppBar(
    backgroundColor: Constants.kPrimaryColor,
    elevation: 0,
    leading: IconButton(
      icon: Icon(
        Icons.arrow_back_ios, color: Colors.white
      ),
      onPressed: () {
       Navigator.pop(context);
      },
      color: Colors.white,
    ),
    title: Text(
      title!,
      style: TextStyle(
        fontFamily: " ",
        color: Colors.white,
        fontSize: 18.0
      ),
      ),
  );
}

Widget topMenu({String? title, IconData? icon, Color? color, Function()? route}) {
  return InkWell(
    onTap: route,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          icon,
          color: color,
          size: 25.0,
        ),
        SizedBox(
          height: 10.0, 
        ),
        Text(
          title!,
          style: TextStyle(fontSize: 12.0),
          overflow: TextOverflow.ellipsis,
        ),
      ],
    ),
  );
}



Widget dashboardCards({String? title, String? total, Widget? icon, Color? bg}) {
  return Card(
    child: Container(
      decoration: BoxDecoration(
       color: bg, 
       borderRadius: BorderRadius.circular(4.0)
      ),
      padding: EdgeInsets.fromLTRB(8.0, 5.0, 8.0, 5.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 30,
            height: 40,
            child: icon,
          ),
          SizedBox(
            width: 10.0,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
               Text(
                title!,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(
                height: 15.0,
              ),
              Text(
                total!,
                style: TextStyle(fontWeight: FontWeight.w500,),
                overflow: TextOverflow.ellipsis,
              ),
              
            ],
          ),
        ],
      ),
    ),
  );
}





Widget menus({String? title, IconData? icon, Color? color}) {
  return InkWell(
    onTap: (){},
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          backgroundColor: Color(0XFFEAF0F1),
          child: Icon(
            icon, color: color,
            size: 25.0,
          ),
        ),
        SizedBox(
          height: 10.0, 
        ),
        Text(
          title!,
          style: TextStyle(fontSize: 12.0),
          overflow: TextOverflow.ellipsis,
        ),
      ],
    ),
  );
}


Widget newsCards({String? title, String? total, Widget? icon, Color? bg}) {
  return Card(
    child: Container(
      decoration: BoxDecoration(
       color: bg, 
       borderRadius: BorderRadius.circular(4.0)
      ),
      padding: EdgeInsets.fromLTRB(8.0, 5.0, 8.0, 5.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                 Text(
                  title!,
                 style: TextStyle(),
                 textAlign: TextAlign.justify,
                ),
              ],
            ),
          ),
           SizedBox(
                width: 10.0,
              ),
              Container(
            width: 100,
            height: 80,
            child: icon,
          ),
         
        ],
      ),
    ),
  );
}


myMenu({Function()? route, IconData? icon1, String? title, IconData? icon2}){
   return Column(
              children: <Widget>[
                Container(
                  height: 50.0,
                  color: Colors.white,
                  child: InkWell(
                    onTap: route,
                    child:Container(
                      padding: EdgeInsets.fromLTRB(15.0, 5.0, 15.0, 5.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                        children: <Widget>[
                          Icon(icon1, color: Colors.black87, size: 20.0,),
                          SizedBox(width: 20.0),
                          Text(
                            title!,
                            style: TextStyle(fontSize: 16.0,  color: Colors.black87, fontFamily: 'SourceSerifPro' ), 
                            ),
                        ],
                      ),
                      Icon(icon2, color: Colors.black87,),
                        ],
                      ),
                    )
                  )
                ),
                SizedBox(height: 10.0,),
              ],
            );
 }


 // ignore: must_be_immutable
 class DynamicWidget extends StatelessWidget {
  TextEditingController questionController = new TextEditingController(); 
  TextEditingController aController = new TextEditingController();
  TextEditingController bController = new TextEditingController(); 
  TextEditingController cController = new TextEditingController();
  TextEditingController dController = new TextEditingController(); 
  TextEditingController answerController = new TextEditingController();
  final formKey = new GlobalKey<FormState>();
 
  bool isLoading = false;

  String? question;
  String? a;
  String? b;
  String? c;
  String? d;
  String? answer;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              padding: EdgeInsets.all(5.0),
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3.0),
                color: Colors.teal
              ),
              child: Text('Question  2', style: TextStyle(fontFamily: 'Alike', fontWeight: FontWeight.w600,color: Colors.white),)
              ),
            SizedBox(height: 10,),
         TextFormField(
                maxLines: 3,
                controller: questionController,
                onSaved: (val) => question = val,
                validator: (val) => val!.length == 0
                          ? 'Enter test question'
                          : null,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.all(15),
                  hintText: 'Question',
                   filled: true,  
                    fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800]!),
                        borderRadius: BorderRadius.circular(5), 
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!,style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(5),
                    ),
                )
              ),
              Divider(height: 10,),
                TextFormField(
                maxLines: 1,
                controller: aController,
                onSaved: (val) => a = val,
                validator: (val) => val!.length == 0
                          ? 'Enter option A'
                          : null,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.all(15),
                  hintText: 'A',
                   filled: true,  
                    fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800]!),
                        borderRadius: BorderRadius.circular(5), 
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!,style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(5),
                    ),
                )
              ),
              Divider(height: 10,),
                TextFormField(
                maxLines: 1,
                controller: bController,
                onSaved: (val) => b = val,
                 validator: (val) => val!.length == 0
                          ? 'Enter option B'
                          : null,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.all(15),
                  hintText: 'B',
                   filled: true,  
                    fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800]!),
                        borderRadius: BorderRadius.circular(5), 
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!,style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(5),
                    ),
                )
              ),
              Divider(height: 10,),
                TextFormField(
                maxLines: 1,
                controller: cController,
                onSaved: (val) => c = val,
                validator: (val) => val!.length == 0
                          ? 'Enter option C'
                          : null,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.all(15),
                  hintText: 'C',
                   filled: true,  
                    fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800]!),
                        borderRadius: BorderRadius.circular(5), 
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!,style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(5),
                    ),
                )
              ),
              Divider(height: 10,),
                TextFormField(
                maxLines: 1,
                controller: dController,
                onSaved: (val) => d = val,
                validator: (val) => val!.length == 0
                          ? 'Enter option D'
                          : null,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.all(15),
                  hintText: 'D',
                   filled: true,  
                    fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800]!),
                        borderRadius: BorderRadius.circular(5), 
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!,style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(5),
                    ),
                )
              ),
              Divider(height: 10,),
                TextFormField(
                maxLines: 1,
                controller: answerController,
                onSaved: (val) => answer = val,
                validator: (val) => val!.length == 0
                          ? 'Enter correct answer'
                          : null,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.all(15),
                  hintText: 'Answer',
                   filled: true,  
                    fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800]!),
                        borderRadius: BorderRadius.circular(5), 
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!,style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(5),
                    ),
                )
              ),
              Divider(height: 20, color: Colors.teal,),
          ],
        );
  }
}



 formTextStyle() {
  return TextStyle(
    fontSize: 12,
    color: Colors.black54,
    fontFamily: 'Raleway',
  );
}








  List<DropdownMenuItem<String>> classItems = [];
  List<DropdownMenuItem<String>> semesterItems = [];
    String? selectedClass ;
    String? selectedSemester ;

    

   void loadData () { 
     classItems = [];
     semesterItems = [];

     classItems.add(new DropdownMenuItem(
     child: Text('100-Level', style: formTextStyle(),),
     value: '1',
   ));

   classItems.add(new DropdownMenuItem(
     child: Text('200-Level', style: formTextStyle(),),
     value: '2',
   ));

    classItems.add(new DropdownMenuItem(
     child: Text('300-Level', style: formTextStyle(),),
     value: '3',
   ));

   classItems.add(new DropdownMenuItem(
     child: Text('400-Level', style: formTextStyle(),),
     value: '4',
   ));





    semesterItems.add(new DropdownMenuItem(
     child: Text('First Semester', style: formTextStyle(),),
     value: '1',
   ));

   semesterItems.add(new DropdownMenuItem(
     child: Text('Second Semester', style: formTextStyle(),),
     value: '2',
   ));

   }


   Widget coursesIcon(context, String? course, String? lecturer, String? code, Function()? route, Function()? route2, fetchCourseData){
  return Column(
    children: [
      GestureDetector(
                      onTap: route!,
                      child: Material(
                        elevation: 5,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            // borderRadius: BorderRadius.only(topLeft: Radius.circular(12)),
                           border: Border(left: BorderSide(width: 5.0, color: Constants.kPrimaryColor.withOpacity(0.6))) 
                          ),
                        width: MediaQuery.of(context).size.width,
                        child:
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Image.asset('img/manual.png',height: 80, width: 90,),
                                      SizedBox(
                                    width: 10.0,
                                  ),
                                  Flexible(
                                    child: Padding(
                                      padding: const EdgeInsets.only(top:8.0),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                            Text(
                                              course!,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                fontSize: 11.0,
                                                fontFamily: 'Quando',
                                                color: Colors.black,
                                                fontWeight: FontWeight.w600
                                              ),
                                              
                                            ),
                                            
                                            SizedBox( height: 5.0,),
                                            Text(
                                              "Level: $lecturer",
                                              style: TextStyle(
                                                fontSize: 12.0,
                                                color: Colors.black54,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            SizedBox( height: 5.0,),
                                            Text(
                                              "Semester: $code",
                                              style: TextStyle(
                                                fontSize: 12.0,
                                                color: Colors.black54,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                   
                                  SizedBox(
                                    height: 5.0,
                                  ),
                                  
                          ],
                        ),
                                ),
                        IconButton(
                          icon: Icon(Icons.delete,size: 20, color: Colors.black54,),
                          onPressed: route2
                        )
                              ],
                            ),
                      ),
                      ),
                    ),
                    SizedBox(height: 10,),
    ],
  );
}

void showInternetError(context) {
    CoolAlert.show(
          context: context,
          type: CoolAlertType.warning,
          title: 'Oops...',
          text: 'No internet connection!',
          loopAnimation: true,
          backgroundColor: Constants.kPrimaryColor,
        );

  }


void showAmountError(context) {
     CoolAlert.show(
          context: context,
          type: CoolAlertType.error,
          title: 'Oops...',
          text: 'Minimum amount is NGN500',
          loopAnimation: true,
          backgroundColor: Constants.kPrimaryColor,
        );
  }

  void showBitcoinError(context) {
    CoolAlert.show(
          context: context,
          type: CoolAlertType.error,
          title: 'Oops...',
          text: 'Minimum amount is 0.000029',
          loopAnimation: true,
          backgroundColor: Constants.kPrimaryColor,
        );
  }


 void showBitcoinInsufficientError(context) {
        CoolAlert.show(
          context: context,
          type: CoolAlertType.error,
          title: 'Oops...',
          text: 'Your balance is not sufficient for this transaction',
          loopAnimation: true,
          backgroundColor: Constants.kPrimaryColor,
        );
  }
  

 void showLoadingDialog(context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          content: Row(
            children: <Widget>[
              new CircularProgressIndicator(),
              SizedBox(
                width: 25.0,
              ),
              new Text("Please wait..."),
            ],
          ),
        );
      },
    );
  }

  Widget transactionCard({String? title, String? transactionId, String? date, String? price}) {

  return title! != null ? Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisAlignment: MainAxisAlignment.start,
                           children: [
                             InkWell(
                               onTap: (){
                   
                               },
                               child: Padding(
                                 padding: const EdgeInsets.all(8.0),
                                 child: Row(
                                   crossAxisAlignment: CrossAxisAlignment.center,
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Row(
                                       crossAxisAlignment: CrossAxisAlignment.start,
                                       children: [
                                         Icon(FontAwesomeIcons.bitcoin,  color: Constants.kPrimaryColor2, size: 40,),
                                         SizedBox(width: 20.0,),
                                         Column(
                                           crossAxisAlignment: CrossAxisAlignment.start,
                                           mainAxisAlignment: MainAxisAlignment.start,
                                           children: [
                                             Text(
                                               title,
                                                style: TextStyle(
                                               fontFamily: "Raleway",
                                               fontSize: 14.0,
                                               fontWeight: FontWeight.w600,
                                               color: Colors.black87
                                               ),
                                               ),
                                               SizedBox(height: 5,),
                                               Text(
                                               transactionId!,
                                                style: TextStyle(
                                               fontFamily: "Raleway",
                                               fontSize: 12.0,
                                               fontWeight: FontWeight.w400,
                                               color: Colors.black45
                                               ),
                                               ),
                                                SizedBox(height: 3,),
                                               Text(
                                               date!,
                                                style: TextStyle(
                                               fontFamily: "Raleway",
                                               fontSize: 12.0,
                                               fontWeight: FontWeight.w400,
                                               color: Colors.black45
                                               ),
                                               ),
                                           ],
                                         ),
                                         
                                       ],
                                     ),
                                     Text(
                                     price!,
                                       style: TextStyle(
                                     fontFamily: "Raleway",
                                     fontSize: 14.0,
                                     fontWeight: FontWeight.w600,
                                     color: Colors.black87,
                                 
                                     ),
                                     ),
                                   ],
                                 ),
                               ),
                             ),
                             Divider( height: 0.0,),
                           ],
                         )
                         :
                         Column(
                           crossAxisAlignment: CrossAxisAlignment.center,
    mainAxisAlignment: MainAxisAlignment.center,
                         children: [
                           Text(
                      'No Record Found!',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.robotoMono(textStyle:
                        TextStyle(
                          color: Constants.kPrimaryColor,
                          fontSize: 25.0,
                          fontWeight: FontWeight.w800),
                          
                      )
                    ) 
                         ],
                       )
                         ;

}

Widget chooseMenu(context, String? text, IconData? icon, Function()? route, Color? color) {
  return Container(
    height: MediaQuery.of(context).size.height ,
    width: MediaQuery.of(context).size.width,
    child: Card(
      child: InkWell(
        highlightColor: Constants.kPrimaryColor.withOpacity(0.3),
        onTap: route,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon!, size: 40, color: color!,),
            SizedBox(
              height: 20.0,
            ),
            Text(
              text!,
              style: TextStyle(
                fontSize: 14.0,
                fontFamily: 'Quando',
                color: Colors.black54,
              ),
            )
          ],
        ),
      ),
    ),
  );
}