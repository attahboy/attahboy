import 'dart:async';

import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/home/home.dart';
import 'package:naija_coin/screens/home/landing_page.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// ignore: import_of_legacy_library_into_null_safe
import 'package:flutter_spinkit/flutter_spinkit.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  var spinkit = SpinKitThreeBounce(
  color: Colors.white,
  size: 25.0,
);

var ss =  SpinKitFadingCircle(
  itemBuilder: (BuildContext context, int index) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: index.isEven ? Colors.red : Colors.green,
      ),
    );
  },
);

bool?  isActive ;



   @override
  void initState(){
    super.initState();
    Timer(Duration(seconds: 4), (){
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => LandingPage(),
      ));
    });
  }
  
   @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitDown, DeviceOrientation.portraitUp]
    );
    return Scaffold(
   backgroundColor: Constants.kPrimaryColor.withOpacity(.03),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
         decoration: BoxDecoration(
                 color: Constants.kPrimaryColor
                ),
        child: Stack(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.center, 
            mainAxisAlignment: MainAxisAlignment.center, 
            children: <Widget>[
            
                Center(
                  child: Column(
                    children: [
                      Image.asset('img/naija_coin.png', height: 150, width: 150,),
                      Text(
                        'Naija Coin',
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Colors.white,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                        )
                      ),
                       SizedBox(
                height: 20.0,
              ),
              Container(
                child: spinkit,
              ),
                    ],
                  ),
                ),   
            ],
          )
        ],
      ),
      ),  
    );
  }
} 