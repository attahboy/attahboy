import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/home/admin_login.dart';
import 'package:naija_coin/screens/home/home.dart';
import 'package:naija_coin/screens/home/login.dart';
import 'package:naija_coin/util/constants.dart';

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {

 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
           children: [
            Container(
          height: screenHeight(context, percent: 0.44),
          width: screenWidth(context),
          decoration: BoxDecoration(
            color: Constants.kPrimaryColor,
            borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(8),
            bottomRight: Radius.circular(8),
          ),
          image: DecorationImage(
            image: AssetImage("img/bit.png"),
            fit: BoxFit.contain,
          ),
          ),
          ),
          YMargin(30),
          Center(
            child: Text(
            'Sign up to invite friend and earn free Bitcoin',
            style: GoogleFonts.raleway(
              textStyle: TextStyle(
                fontSize: 16.0,
                color: Colors.black54
              ),
            ),
        ),
          ),
        YMargin(20),
         Padding(
           padding: const EdgeInsets.only(left: 20.0, right: 20.0),
           // ignore: deprecated_member_use
           child: FlatButton(
                  color: Constants.kPrimaryColor,
                  child: Text(
                      'USER',
                      style: TextStyle(fontSize: 14),
                  ),
                  shape: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1),
                      borderRadius: BorderRadius.circular(30.0),
                  ),
                  padding: EdgeInsets.all(18),
                  textColor: Colors.white,
                  onPressed: () {
                       Future.delayed(Duration.zero, () async{
                      await Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                      });
                  },
                ),
         ),
          YMargin(20),
         Padding(
           padding: const EdgeInsets.only(left: 20.0, right: 20.0),
           // ignore: deprecated_member_use
           child: FlatButton(
                  color: Constants.kPrimaryColor2,
                  child: Text(
                      'ADMINISTRATOR',
                      style: TextStyle(fontSize: 14),
                  ),
                  shape: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1),
                      borderRadius: BorderRadius.circular(30.0),
                  ),
                  padding: EdgeInsets.all(18),
                  textColor: Colors.white,
                  onPressed: () {
                       Future.delayed(Duration.zero, () async{
                      await Navigator.push(context, MaterialPageRoute(builder: (context) => AdminLogin()));
                      });
                  },
                ),
         ),
           ], 
          ),
      ),
    );
  }
}