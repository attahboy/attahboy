import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:naija_coin/screens/home/login.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;

bool isLoadingAdmin = false;
bool isLoading = false;
bool _passwordViewAdmin = true;
// ignore: unused_element
bool _passwordView = true;
bool? isLoggedIn ;
bool? isLoggedInAdmin;

class Signup extends StatefulWidget {
  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {

  // ignore: unused_field
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final formKey = new GlobalKey<FormState>();


  TextEditingController nameController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController phoneController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();


  String? phone;
  String? name;
  String? email;
  String? password;
  // ignore: non_constant_identifier_names
  final String BTC_balance = '0.0';
  // ignore: non_constant_identifier_names
  final String NGN_balance = '0.0';
  String? user;
  var result;
  List? userData;


   _showSuccessSnackBar() {
    final snackbar = new SnackBar(
      content: new Text('Account Created successfully',
          style: TextStyle(fontSize: 16.0, color: Colors.greenAccent)),
      onVisible: () {
        Timer(Duration(seconds: 3), () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => Login()));
        });
      },
      backgroundColor: Colors.black87,
    );
    // ignore: deprecated_member_use
    _scaffoldKey.currentState!.showSnackBar(snackbar);
  }


  _saveUserData() async{
    if (formKey.currentState!.validate()) {
      result = await Connectivity().checkConnectivity();
      if (result == ConnectivityResult.mobile ||
        result == ConnectivityResult.wifi) {
           //_showDialog();
            formKey.currentState!.save();
      setState(() {
        isLoading = true;
      });
      isLoading
          ? _showDialog()
          : Navigator.of(context, rootNavigator: true).pop('dialog');
      Timer(Duration(seconds: 3), () {});
          _createUser() ;

        }else{
          _showerr();
                  }
      
    }
  }



      _createUser() async {
          final response =
            await http.post(Uri.parse('https://teamcoded.com.ng/crypto.php'), body: {
            "request": "ADD USER",
            "name": name,
            "email": email,
            "phone": phone,
            "password": password, 
            "status": '1'
      });

     if (response.statusCode == 200) {
       _fetchUserData();
       Timer(Duration(seconds: 3), () {
         _createUserAccount();
        });
      
      
    }
    
     
    }

    _createUserAccount() async {
          final response =
            await http.post(Uri.parse('https://teamcoded.com.ng/crypto.php'), body: {
            "request": "CREATE ACCOUNT",
            "user": user,
            "BTC_balance": BTC_balance,
            "NGN_balance": NGN_balance,
            "status": '1', 
      }); 

      if (response.statusCode == 200) {

       setState(() {
        isLoading = false;
      });

      !isLoading
          ? Navigator.of(context, rootNavigator: true).pop('dialog')
          : _showDialog();
      _showSuccessSnackBar();
      clearForm();
    }
    }

    clearForm(){
      nameController.clear();
      emailController.clear();
      phoneController.clear();
      passwordController.clear();
    }


     Future<List> _fetchUserData() async {
        final response =
        await http.post(Uri.parse("https://teamcoded.com.ng/crypto.php"), body: {
        "request": "FETCH USER DETAILS",
        "email" : email,
          });
          var convertDateToJson = jsonDecode(response.body);
        setState(() {
        userData = convertDateToJson;
        user = userData![0]["User"];
        print(user);
      });
      return userData!;
      }



  void _showDialog() {
    // flutter defined function
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          content: Row(
            children: <Widget>[
              new CircularProgressIndicator(),
              SizedBox(
                width: 25.0,
              ),
              new Text("Please wait..."),
            ],
          ),
        );
      },
    );
  }

   void _showerr() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          content: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              new IconButton(
                onPressed: (){
                  Navigator.of(context, rootNavigator: true).pop('dialog');
                },
                icon: Icon(Icons.cancel, size: 40.0,),
                color: Constants.kPrimaryColor.withOpacity(0.5),
                iconSize: 10,
              ),
              SizedBox(
                width: 25.0,
              ),
              Flexible(child: new Text("No internet connection", style: TextStyle(fontSize: 14),)),
            ],
          ),
        );
      },
    );
  }


  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
         title: Text(""), 
         backgroundColor: Colors.transparent,
         elevation: 0,
         
      ),
      body: SingleChildScrollView(
         primary: false,
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
             children: [
                  YMargin(50.0),
                Center(
                  child: Text(
                    'Sign up',
                    style: TextStyle(
                        color: Constants.kPrimaryColor,
                        fontFamily: 'Quando',
                        fontSize: 24.0,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                YMargin(15.0),
                Center(
                  child: Text(
                  'Already have an account? Sign In',
                  style: TextStyle(
                    color: Colors.black38,
                    fontFamily: 'raleway',
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.left,
              ),
                ),
                   SizedBox(
                      height: 50,
                    ),
               
                       YMargin(10),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 10.0),
                      child: TextFormField(
                        controller: nameController,
                        onSaved: (val) => name = val,
                        validator: (val) => val!.length == 0 ? 'Please enter your name' : null,
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.person, size: 20.0,),
                          hintText: 'Full Name',
                          contentPadding: const EdgeInsets.all(15.0),
                          filled: true,
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                       YMargin(20),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 10.0),
                      child: TextFormField(
                        controller: emailController,
                        onSaved: (val) => email = val,
                        validator: (val) => val!.length == 0 ? 'Please enter your email' : null,
                        keyboardType: TextInputType.emailAddress,
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.email, size: 20.0,),
                          hintText: 'Email',
                          contentPadding: const EdgeInsets.all(15.0),
                          filled: true,
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide.none, 
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    YMargin(20),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 10.0),
                      child: TextFormField(
                        controller: phoneController,
                        onSaved: (val) => phone = val,
                        validator: (val) => val!.length == 0 ? 'Please enter your phone number' : null,
                        keyboardType: TextInputType.phone,
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.phone, size: 20.0,),
                          hintText: 'Phone Number',
                          contentPadding: const EdgeInsets.all(15.0),
                          filled: true,
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    YMargin(20),

                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 10.0),
                      child: TextFormField(
                        controller: passwordController,
                        onSaved: (val) => password = val,
                        validator: (val) => val!.length == 0 ? 'Please enter your passward' : null,
                         obscureText: _passwordViewAdmin,
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.lock, size: 18.0,),
                          suffixIcon: IconButton(
                              icon: Icon(Icons.remove_red_eye, size: 20.0,),
                              onPressed: () {
                               if(_passwordViewAdmin){
                                  setState(() {
                                  _passwordView = false;
                                });
                                }else{
                                  setState(() {
                                  _passwordViewAdmin = true;
                                });
                                }
                              }),
                          hintText: 'Password',
                          contentPadding: const EdgeInsets.all(15.0),
                          filled: true,
                          focusColor: Colors.grey,
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                      SizedBox(height: 30.0,),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 10.0),
                      // ignore: deprecated_member_use
                      child: FlatButton(
                        color: Constants.kPrimaryColor,
                        child: Text(
                          'SIGN UP',
                          style: TextStyle(fontSize: 14),
                        ),
                        shape: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white, width: 1),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        padding: EdgeInsets.all(18),
                        textColor: Colors.white,
                        onPressed: () {
                        _saveUserData();
                      //   Navigator.pushReplacement((context), MaterialPageRoute(builder: (context) => BottomNav()));
                        },
                      ),
                    ),
                     SizedBox(
                    height: 20,
                  ),
                  
             ], 
            ),
          ),
      ),
    );
  }
}