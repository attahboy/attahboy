import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/home/signup.dart';
import 'package:naija_coin/screens/home/login.dart';
import 'package:naija_coin/screens/user/dashboard.dart';
import 'package:naija_coin/util/constants.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
bool? isLoggedIn ;

  @override
  void initState() {
    super.initState();
   getData();
   checkLoginState();
    
  }

    getData() {
      setState(() {
      isLoggedIn = Constants.sharedPref!.getBool("isLoggedInUser");
      });
  }

      checkLoginState()  { 
    if (isLoggedIn != null) {
      // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => BottomNav()));
       Future.delayed(Duration.zero, () async{
          // Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => BottomNav()), (Route<dynamic> route) => false);
         await  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => UserDashboard()));
          });
    }else{

    }
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
           children: [
            Container(
          height: screenHeight(context, percent: 0.44),
          width: screenWidth(context),
          decoration: BoxDecoration(
            color: Constants.kPrimaryColor,
            borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(8),
            bottomRight: Radius.circular(8),
          ),
          image: DecorationImage(
            image: AssetImage("img/coins.png"),
            fit: BoxFit.contain,
          ),
          ),
          ),
          YMargin(30),
          Center(
            child: Text(
            'Sign up to invite friend and earn free Bitcoin',
            style: GoogleFonts.raleway(
              textStyle: TextStyle(
                fontSize: 16.0,
                color: Colors.black54
              ),
            ),
        ),
          ),
        YMargin(20),
         Padding(
           padding: const EdgeInsets.only(left: 20.0, right: 20.0),
           // ignore: deprecated_member_use
           child: FlatButton(
                  color: Constants.kPrimaryColor,
                  child: Text(
                      'GET STARTED',
                      style: TextStyle(fontSize: 14),
                  ),
                  shape: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1),
                      borderRadius: BorderRadius.circular(30.0),
                  ),
                  padding: EdgeInsets.all(18),
                  textColor: Colors.white,
                  onPressed: () {
                       Future.delayed(Duration.zero, () async{
                      await Navigator.push(context, MaterialPageRoute(builder: (context) => Signup()));
                      });
                  },
                ),
         ),
          YMargin(20),
         Padding(
           padding: const EdgeInsets.only(left: 20.0, right: 20.0),
           // ignore: deprecated_member_use
           child: FlatButton(
                  color: Constants.kPrimaryColor2,
                  child: Text(
                      'SIGN IN',
                      style: TextStyle(fontSize: 14),
                  ),
                  shape: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1),
                      borderRadius: BorderRadius.circular(30.0),
                  ),
                  padding: EdgeInsets.all(18),
                  textColor: Colors.white,
                  onPressed: () {
                       Future.delayed(Duration.zero, () async{
                      await Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                      });
                  },
                ),
         ),
           ], 
          ),
      ),
    );
  }
}