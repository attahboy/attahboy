import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/reviewBuy.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:naija_coin/widgets/users_widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;

class Buy extends StatefulWidget {
  const Buy({ Key? key }) : super(key: key);
  @override
  _BuyState createState() => _BuyState();
}

class _BuyState extends State<Buy> {

  final formKey = new GlobalKey<FormState>();

  final TextEditingController nairaController = new TextEditingController();
   

  String? naira;
  String? btc;
  var result;
  List? userData;

  final double oneBTC = 0.000000059;

   var spinkit = SpinKitDualRing(
      color: Colors.white,
      size: 15.0,
    );

    _validateForm(context) async{
      if (formKey.currentState!.validate()) {

          result = await Connectivity().checkConnectivity();

          if (result == ConnectivityResult.mobile || result == ConnectivityResult.wifi) {
                formKey.currentState!.save();
                  if (int.parse(naira!) < 500) {
                    showAmountError(context);
                  }else{
                   Navigator.push(context, MaterialPageRoute(builder: (context) => ReviewBuy(buyAmount: naira, buyBTC: btc,)));
                  }
            }else{
                formKey.currentState!.save();
                showInternetError(context);
            }
      
    }
  }


  String format(double n) {
    return n.toStringAsFixed(n.truncateToDouble() == n ? 0 : 2);
  }

  _calculateBTC(naira){
     var btcAmount =   double.parse(naira) * oneBTC;
     setState(() {
       btc = btcAmount.toString();
     });
  }

   Future<List> _fetchUserData() async {
        final response =
        await http.post(Uri.parse("https://teamcoded.com.ng/crypto.php"), body: {
        "request": "FETCH USER DETAILS BY ID",
        "user" : userID,
          });
          var convertDateToJson = jsonDecode(response.body);
        setState(() {
        userData = convertDateToJson;
      });
      return userData!;
      }

getData() {
      setState(() {
      userID = Constants.sharedPref!.getString("user");
      });
}

      
@override
  void initState() {
    getData();
    _fetchUserData();
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: singleAppBar(title: 'Buy Bitcoin', context: context,),
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child: Form(
            key: formKey,
            child: ListView(
            children: [
             Container(
              height: screenHeight(context)*0.15,
              width: screenWidth(context),
              decoration: BoxDecoration(
                color:  Constants.kPrimaryColor
              ),
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  userData !=null ?  
                  Text(
                        'BTC ${ double.parse(userData![0]["BTC_balance"])  }',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      )  : Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                        Text(
                        'BTC  ',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ) ,
                        spinkit,
                      ],),
                      YMargin(4.0),
                      userData !=null ? Text(
                        '-NGN ${ userData![0]["NGN_balance"] }',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ) :  Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                        Text(
                        '-NGN  ',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ) ,
                        spinkit,
                      ],),
                ],
              ),
             ),
             
              Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 40.0, 8.0, 10.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              TextFormField(
                                style: TextStyle(
                                    fontSize: 16, color: Colors.black54),
                                    textCapitalization: TextCapitalization.sentences,
                                    keyboardType: TextInputType.number,
                                    autofocus: true,
                                decoration: InputDecoration(
                                  labelText: 'NGN',
                                  hintStyle: TextStyle(fontSize: 14),
                                  contentPadding: const EdgeInsets.all(10),
                                  filled: true,
                                  fillColor: Colors.white,
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                    color: Colors.grey[300]!,
                                  )),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                    color: Colors.grey[300]!,
                                  )),
                                  suffix: Icon(Icons.money,),
                                ),
                                validator: (val) =>
                                    val!.length == 0 ? 'This field is required' : null,
                                controller: nairaController,
                                onSaved: (val) => naira = val,
                                onChanged: (value) => _calculateBTC(value),
                              ),
                            ],
                          ),
                        ),
                        Padding(padding: EdgeInsets.all(5.0)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                              TextFormField(
                                style: TextStyle(
                                    fontSize: 16, color: Colors.black54),
                                    textCapitalization: TextCapitalization.sentences,
                                decoration: InputDecoration(
                                  labelText: 'BTC',
                                  labelStyle: TextStyle(fontSize: 14),
                                  contentPadding: const EdgeInsets.all(10),
                                  filled: true,
                                  fillColor: Colors.white,
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                    color: Colors.grey[300]!,
                                  )),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                    color: Colors.grey[300]!,
                                  )),
                                  suffix: Icon(FontAwesomeIcons.bitcoin)
                                ),
                                readOnly: true,
                                validator: (val) =>
                                    val!.length == 0 ?  'This field is required' : null,
                                controller: TextEditingController(text: btc !=null ? btc.toString() : '0.0'),
                                onSaved: (val) => btc = val,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

               Padding(
                 padding: const EdgeInsets.fromLTRB(8.0, 20.0, 8.0, 10.0),
                 // ignore: deprecated_member_use
                 child: FlatButton(
                    color: Constants.kPrimaryColor.withOpacity(0.7),
                    child: Text(
                        'Proceed',
                        style: TextStyle(fontSize: 14),
                    ),
                    shape: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white, width: 1),
                        borderRadius: BorderRadius.circular(3.0),
                    ),
                    padding: EdgeInsets.all(18),
                    textColor: Colors.white,
                    onPressed: () {
                      _validateForm(context) ;
                        //  Future.delayed(Duration.zero, () async{
                        // await Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                        // });
                    },
                  ),
               ),
                      
            ],
          ),
          ),
        ),
    );
  }
}