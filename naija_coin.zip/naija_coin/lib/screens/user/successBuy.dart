import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/dashboard.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:naija_coin/widgets/users_widget.dart';
import 'package:intl/intl.dart';

class SuccessBuy extends StatefulWidget {
  const SuccessBuy({ Key? key, this.buyBTC, this.buyAmount, this.ref}) : super(key: key);
  final buyBTC;
  final buyAmount;
  final ref;
  @override
  _SuccessBuyState createState() => _SuccessBuyState();
}

class _SuccessBuyState extends State<SuccessBuy> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: singleAppBar(title: 'Success', context: context,),
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child: ListView(
          children: [

            Padding(
              padding: const EdgeInsets.fromLTRB(8.0, 10.0, 8.0, 5.0),
              child: Icon(Icons.check_circle, size: 140, color: Constants.kPrimaryColor2,),
            ),

            Text(
                        'Transaction was successful',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor.withOpacity(0.6),
                            fontSize: 18.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ),

                      Divider(),

             Padding(
              padding: const EdgeInsets.fromLTRB(15.0, 5.0, 15.0, 10.0),
              child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                             Text(
                              'Transaction ref',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                      Padding(padding: EdgeInsets.all(1.0)),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                          
                             Text(
                              '${widget.ref}',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
            ),
           
            Padding(
              padding: const EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 10.0),
              child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                             Text(
                              'You buy',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                      Padding(padding: EdgeInsets.all(1.0)),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                          
                             Text(
                              ' BTC ${widget.buyBTC}',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
            ),

           

            Padding(
              padding: const EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 10.0),
              child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                             Text(
                              'Service Charges',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                      Padding(padding: EdgeInsets.all(10.0)),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                          
                             Text(
                              'NGN 50.00',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
            ),

             Padding(
              padding: const EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 10.0),
              child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                             Text(
                              'Amount payable',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                      Padding(padding: EdgeInsets.all(10.0)),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                          
                             Text(
                              'NGN ${double.parse(widget.buyAmount) + 50}',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 30.0),
              child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                             Text(
                              'Transaction Date',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                      Padding(padding: EdgeInsets.all(10.0)),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                          
                             Text(
                              '${DateFormat.yMMMd().format(DateTime.now())}',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.robotoMono(textStyle:
                                TextStyle(
                                  color: Constants.kPrimaryColor,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w800),
                                  
                              )
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
            ),


             Padding(
               padding: const EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 10.0),
               // ignore: deprecated_member_use
               child: FlatButton(
                  color: Constants.kPrimaryColor.withOpacity(0.7),
                  child: Text(
                      'DASHBOARD',
                      style: TextStyle(fontSize: 14),
                  ),
                  shape: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1),
                      borderRadius: BorderRadius.circular(3.0),
                  ),
                  padding: EdgeInsets.all(18),
                  textColor: Colors.white,
                  onPressed: () {
                       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => UserDashboard()));
                  },
                ),
             ),
                    
          ],
          ),
        ),
    );
  }
}