import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/buy.dart';
import 'package:naija_coin/screens/user/news.dart';
import 'package:naija_coin/screens/user/sell.dart';
import 'package:naija_coin/screens/user/wallet.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;
import 'package:naija_coin/widgets/users_widget.dart';

class UserDashboard extends StatefulWidget {
  @override
  _UserDashboardState createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> {


  List<Color> gradientColors = [
    const Color(0xff23b6e6),
    const Color(0xff02d39a),
  ];

  bool showAvg = false;
  List? transactionData;

      
  Future<List> _fetchTransactionData() async {
        final response =
        await http.post(Uri.parse("https://teamcoded.com.ng/crypto.php"), body: {
        "request": "FETCH USER TRANSACTIONS",
        "user" : userID,
          });
          var convertDateToJson = jsonDecode(response.body);
        setState(() {
        transactionData = convertDateToJson;
      });
      return transactionData!;
      }

getData() {
      setState(() {
      userID = Constants.sharedPref!.getString("user");
      });
}

      
@override
  void initState() {
    getData();
    _fetchTransactionData();
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: screenHeight(context),
        width: screenWidth(context),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: Container(
                height: screenHeight(context, percent: 0.44),
                width: screenWidth(context),
                decoration: BoxDecoration(
                  color: Constants.kPrimaryColor,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(8),
                    bottomRight: Radius.circular(8),
                  ),
                  // image: DecorationImage(
                  //   image: AssetImage("img/coins.png"),
                  //   fit: BoxFit.contain,
                  // ),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(0, 35, 18, 30),
                  child: LineChart(
                    LineChartData(
                       gridData: FlGridData(
                      show: true,
                      drawVerticalLine: true,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                          color: const Color(0xff37434d),
                          strokeWidth: 1,
                        );
                      },
                      getDrawingVerticalLine: (value) {
                        return FlLine(
                          color: const Color(0xff37434d),
                          strokeWidth: 1,
                        );
                      },
                    ),
                     titlesData: FlTitlesData(
                    show: true,
                    bottomTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 22,
                      getTextStyles: (value) =>
                          const TextStyle(color: Constants.kPrimaryColor2, fontWeight: FontWeight.bold, fontSize: 12),
                      getTitles: (value) {
                        switch (value.toInt()) {
                          case 2:
                            return 'JUN';
                          case 5:
                            return 'JUL';
                          case 8:
                            return 'AUG';
                        }
                        return '';
                      },
                      margin: 8,
                    ),
                    leftTitles: SideTitles(
                      showTitles: true,
                      getTextStyles: (value) => const TextStyle(
                        color: Constants.kPrimaryColor2,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                      getTitles: (value) {
                        switch (value.toInt()) {
                          case 1:
                            return '10M';
                          case 3:
                            return '20M';
                          case 5:
                            return '30M';
                        }
                        return '';
                      },
                      reservedSize: 28,
                      margin: 12,
                    ),
                  ),
                  borderData: FlBorderData(show: true, border: Border.all(color: const Color(0xff37434d), width: 1)),
                      minX: 0,
                      maxX: 11,
                      minY: 0,
                      maxY: 6,
                      lineBarsData: [
                        LineChartBarData(
                          spots: [
                            FlSpot(0, 3),
                            FlSpot(2.6, 2),
                            FlSpot(4.9, 5),
                            FlSpot(6.8, 2.5),
                            FlSpot(8, 4),
                            FlSpot(9.5, 3),
                            FlSpot(11, 4),
                          ],
                          isCurved: true,
                        colors: gradientColors,
                        barWidth: 5,
                        isStrokeCapRound: true,
                        dotData: FlDotData(
                          show: false,
                        ),
                        belowBarData: BarAreaData(
                          show: true,
                          colors: gradientColors.map((color) => color.withOpacity(0.3)).toList(),
                        ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            YMargin(30),
            Positioned(
              top: 360,
              left: 20,
              child: Text(
                'TRANSACTION HISTORY',
                style: GoogleFonts.sourceSansPro(
                  textStyle: TextStyle(fontSize: 14.0, color: Colors.black54, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            Positioned(
              top: 278,
              left: 20,
              right: 20,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.only(left:8.0, right: 8.0, bottom: 3.0, top: 3.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                     InkWell(
                        onTap: (){
                           Navigator.push(context, MaterialPageRoute(builder: (context) => Buy()));
                        }, 
                       child: Column(
                         crossAxisAlignment: CrossAxisAlignment.center,
                         mainAxisAlignment: MainAxisAlignment.center,
                         children: [
                          Icon(FontAwesomeIcons.bitcoin, size: 30, color: Constants.kPrimaryColor,),
                          YMargin(8.0),
                           Text(
                          'BUY',
                          style: GoogleFonts.robotoMono(
                            textStyle: TextStyle(fontSize: 12.0, color: Constants.kPrimaryColor, fontWeight: FontWeight.bold),
                          ),
                        ),
                         ],
                       ),
                     ),
                     InkWell(
                        onTap: (){
                           Navigator.push(context, MaterialPageRoute(builder: (context) => Sell()));
                        },  
                       child: Column(
                         crossAxisAlignment: CrossAxisAlignment.center,
                         mainAxisAlignment: MainAxisAlignment.center,
                         children: [
                            Icon(FontAwesomeIcons.moneyBillAlt, size: 25, color: Constants.kPrimaryColor,), 
                            YMargin(8.0),
                           Text(
                          'SELL',
                          style: GoogleFonts.robotoMono(
                            textStyle: TextStyle(fontSize: 12.0, color: Constants.kPrimaryColor, fontWeight: FontWeight.bold),
                          ),
                        ),
                         ],
                       ),
                     ),
                     InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => News()));
                        }, 
                       child: Column(
                         crossAxisAlignment: CrossAxisAlignment.center,
                         mainAxisAlignment: MainAxisAlignment.center,
                         children: [
                           Icon(FontAwesomeIcons.newspaper, size: 25, color: Constants.kPrimaryColor,),
                           YMargin(8.0),
                           Text(
                          'NEWS',
                          style: GoogleFonts.robotoMono(
                            textStyle: TextStyle(fontSize: 12.0, color: Constants.kPrimaryColor, fontWeight: FontWeight.bold),
                          ),
                        ), 
                         ],
                       ),
                     ),

                     InkWell(
                        onTap: (){
                           Navigator.push(context, MaterialPageRoute(builder: (context) => Wallet()));
                        }, 
                       child: Column(
                         crossAxisAlignment: CrossAxisAlignment.center,
                         mainAxisAlignment: MainAxisAlignment.center,
                         children: [
                           Icon(FontAwesomeIcons.userCircle, size: 25, color: Constants.kPrimaryColor,),
                           YMargin(8.0),
                           Text(
                          'ACCOUNT',
                          style: GoogleFonts.robotoMono(
                            textStyle: TextStyle(fontSize: 12.0, color: Constants.kPrimaryColor, fontWeight: FontWeight.bold),
                          ),
                        ), 
                         ],
                       ),
                     ),
                    ],
                  ),
                ),
              ),
            ),
             Positioned(
              top: 390,
              left: 10,
              right: 10,
              child: Container(
                height: screenHeight(context, percent: 0.4),
                width: screenWidth(context),
                color: Colors.white,
                child:
                transactionData != null ? ListView.builder(
                shrinkWrap: true,
                 itemCount: transactionData == null ? 0 : transactionData!.length,
                itemBuilder: (BuildContext context, int index) {
                      return transactionCard(
                        title: transactionData![index]["Transaction_type"] == "BuyBTC" ? "Buy BTC" : "Sell BTC",
                        transactionId: transactionData![index]["Transaction_type"] == "BuyBTC" ? "BTC "+transactionData![index]["NGN_amount"] : "NGN "+transactionData![index]["BTC_amount"],
                        price: transactionData![index]["Transaction_type"] == "BuyBTC" ? "BTC "+transactionData![index]["BTC_amount"] : "NGN "+transactionData![index]["NGN_amount"],
                        date: transactionData![index]["Transaction_date"],
                       ); 
                } 
                ) : Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(strokeWidth: 2,),
                      YMargin(5),
                       Text(
                        'Loading...',
                        style: TextStyle( 
                          fontSize: 14.0,
                          fontFamily: 'Quando',
                          color: Colors.black54,
                        ),
                      )
                    ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


