import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/review.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:naija_coin/widgets/users_widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;


class News extends StatefulWidget {
  const News({ Key? key }) : super(key: key);
  @override
  _NewsState createState() => _NewsState();
}

class _NewsState extends State<News> {

  final formKey = new GlobalKey<FormState>();

  final TextEditingController btcController = new TextEditingController();
   

  String? naira;
  String? btc;
  var result;
  List? userData;
  List? newsData;

  var spinkit = SpinKitDualRing(
      color: Colors.white,
      size: 15.0,
    );
   
  final double oneBTC = 17153567.09;

    _validateForm(context) async{
      if (formKey.currentState!.validate()) {

          result = await Connectivity().checkConnectivity();

          if (result == ConnectivityResult.mobile || result == ConnectivityResult.wifi) {
                formKey.currentState!.save();
                  if (btc == null || double.parse(btc!) < 0.000029) {
                    showBitcoinError(context);
                  }else if(double.parse(btc!) > double.parse(userData![0]["BTC_balance"])){
                    showBitcoinInsufficientError(context);
                  }else{
                     Navigator.push(context, MaterialPageRoute(builder: (context) => Review(sellAmount: naira, sellBTC: btc,)));
                  }
            }else{
                formKey.currentState!.save();
                showInternetError(context);
            }
      
    }
  }


  String format(double n) {
    return n.toStringAsFixed(n.truncateToDouble() == n ? 0 : 2);
  }

  _calculateBTC(btc){
     var nairaAmount =   double.parse(btc) * oneBTC;
     setState(() {
       naira =  nairaAmount.toStringAsFixed(2).toString();
     });
  }

   Future<String> _fetchNewsData() async {
        final response =
        await http.get(Uri.parse("https://newsapi.org/v2/top-headlines?country=ng&apiKey=279a151a613b48b482d9c6c18f10bfea"),
        headers: {"Accept": "application/json"});
          var convertDateToJson = jsonDecode(response.body);
        setState(() {
        newsData = convertDateToJson["articles"];
        print(newsData![1]["title"].toString());
      });
      return "Success";
      }

getData() {
      setState(() {
      userID = Constants.sharedPref!.getString("user");
      });
}

      
@override
  void initState() {
    getData();
    _fetchNewsData();
    super.initState();
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: singleAppBar(title: 'News', context: context,),
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child:
          Form(
            key: formKey,
            child: ListView(
              primary: true,
            children: [
             Container(
              height: screenHeight(context)*0.15,
              width: screenWidth(context),
              decoration: BoxDecoration(
                color:  Constants.kPrimaryColor
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
    
                  Text(
                        'News Headling',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ),  
                      YMargin(4.0),
                      
                ],
              ),
             ),

            ListView.builder(
                shrinkWrap: true,
                primary: false,
                 itemCount: newsData !=null ? newsData!.length : 0,
                itemBuilder: (BuildContext context, int index) {
                      return   Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 5.0, 8.0, 5.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Card(
                                elevation: 7,
                                child: Container(
                                  height: screenHeight(context)*0.3,
                                   child: Column(
                                     children: [
                                       Container(
                                         height: screenHeight(context)*0.2,
                                         decoration: BoxDecoration(
                                           borderRadius: BorderRadius.circular(3),
                                          image: DecorationImage( 
                                            image: NetworkImage(newsData![index]["urlToImage"].toString()), fit: BoxFit.fill,
                                          ),
                                         ),
                                       ),
                                       Divider(color: Constants.kPrimaryColor, height: 5,),
                                       YMargin(1),
                                        Flexible(
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(5.0, 0.0, 5.0, 2.0),
                                            child: Text(newsData![index]["title"].toString(),
                                      textAlign: TextAlign.justify,
                                      style: GoogleFonts.robotoMono(textStyle:
                                            TextStyle(
                                              color: Constants.kPrimaryColor,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w600),
                                              
                                      ),
                                    ),
                                    
                                          ),
                                        ),  
                                      YMargin(3),
                                     ], 
                                   ), 
                                ), 
                                
                     
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
              );
                } 
             ),
            
            ],
          ),
          ),
      ),
    );
  }
}