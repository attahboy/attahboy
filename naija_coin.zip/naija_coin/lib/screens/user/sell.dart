import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/review.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:naija_coin/widgets/users_widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;


class Sell extends StatefulWidget {
  const Sell({ Key? key }) : super(key: key);
  @override
  _SellState createState() => _SellState();
}

class _SellState extends State<Sell> {

  final formKey = new GlobalKey<FormState>();

  final TextEditingController btcController = new TextEditingController();
   

  String? naira;
  String? btc;
  var result;
  List? userData;

  var spinkit = SpinKitDualRing(
      color: Colors.white,
      size: 15.0,
    );
   
  final double oneBTC = 17153567.09;

    _validateForm(context) async{
      if (formKey.currentState!.validate()) {

          result = await Connectivity().checkConnectivity();

          if (result == ConnectivityResult.mobile || result == ConnectivityResult.wifi) {
                formKey.currentState!.save();
                  if (btc == null || double.parse(btc!) < 0.000029) {
                    showBitcoinError(context);
                  }else if(double.parse(btc!) > double.parse(userData![0]["BTC_balance"])){
                    showBitcoinInsufficientError(context);
                  }else{
                     Navigator.push(context, MaterialPageRoute(builder: (context) => Review(sellAmount: naira, sellBTC: btc,)));
                  }
            }else{
                formKey.currentState!.save();
                showInternetError(context);
            }
      
    }
  }


  String format(double n) {
    return n.toStringAsFixed(n.truncateToDouble() == n ? 0 : 2);
  }

  _calculateBTC(btc){
     var nairaAmount =   double.parse(btc) * oneBTC;
     setState(() {
       naira =  nairaAmount.toStringAsFixed(2).toString();
     });
  }

   Future<List> _fetchUserData() async {
        final response =
        await http.post(Uri.parse("https://teamcoded.com.ng/crypto.php"), body: {
        "request": "FETCH USER DETAILS BY ID",
        "user" : userID,
          });
          var convertDateToJson = jsonDecode(response.body);
        setState(() {
        userData = convertDateToJson;
      });
      return userData!;
      }

getData() {
      setState(() {
      userID = Constants.sharedPref!.getString("user");
      });
}

      
@override
  void initState() {
    getData();
    _fetchUserData();
    super.initState();
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: singleAppBar(title: 'Sell Bitcoin', context: context,),
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child:
          Form(
            key: formKey,
            child: ListView(
            children: [
             Container(
              height: screenHeight(context)*0.15,
              width: screenWidth(context),
              decoration: BoxDecoration(
                color:  Constants.kPrimaryColor
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  userData !=null ?  
                  Text(
                        'BTC ${double.parse(userData![0]["BTC_balance"])  }',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      )  : Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                        Text(
                        'BTC  ',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ) ,
                        spinkit,
                      ],),
                      YMargin(4.0),
                      userData !=null ? Text(
                        '-NGN ${ userData![0]["NGN_balance"] }',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ) :  Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                        Text(
                        '-NGN  ',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor2,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ) ,
                        spinkit,
                      ],),
                ],
              ),
             ),
             
              Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 40.0, 8.0, 10.0),
                child: Row(
                      children: <Widget>[
                       
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                              TextFormField(
                                style: TextStyle(
                                    fontSize: 16, color: Colors.black54),
                                    textCapitalization: TextCapitalization.sentences,
                                    keyboardType: TextInputType.number,
                                decoration: InputDecoration(
                                  labelText: 'BTC',
                                  labelStyle: TextStyle(fontSize: 14),
                                  contentPadding: const EdgeInsets.all(10),
                                  filled: true,
                                  fillColor: Colors.white,
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                    color: Colors.grey[300]!,
                                  )),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                    color: Colors.grey[300]!,
                                  )),
                                  suffix: Icon(FontAwesomeIcons.bitcoin)
                                ),
                                validator: (val) =>
                                    val!.length == 0 ? 'Enter surname' : null,
                                controller: btcController,
                                onSaved: (val) => btc = val,
                                onChanged: (value) => _calculateBTC(value),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

              YMargin(10.0),
                      Text(
                        'NGN ${naira  !=null ? naira!  : 0.0}',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ),

               Padding(
                 padding: const EdgeInsets.fromLTRB(8.0, 30.0, 8.0, 10.0),
                 // ignore: deprecated_member_use
                 child: FlatButton(
                    color: Constants.kPrimaryColor.withOpacity(0.7),
                    child: Text(
                        'Proceed',
                        style: TextStyle(fontSize: 14),
                    ),
                    shape: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white, width: 1),
                        borderRadius: BorderRadius.circular(3.0),
                    ),
                    padding: EdgeInsets.all(18),
                    textColor: Colors.white,
                    onPressed: () {
                       _validateForm(context);
                    },
                  ),
               ),
                      
            ],
          ),
          ),
      ),
    );
  }
}