import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/successSell.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:naija_coin/widgets/users_widget.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;
import 'package:cool_alert/cool_alert.dart';
 

class Review extends StatefulWidget {
  const Review({ Key? key, this.sellBTC, this.sellAmount}) : super(key: key);
  final sellBTC;
  final sellAmount;
  @override
  _ReviewState createState() => _ReviewState();
}

class _ReviewState extends State<Review> {

  final formKey = new GlobalKey<FormState>();
  Random random = new Random();
  final TextEditingController accountController = new TextEditingController();
   

 bool isLoading = false;
  var result;
  int? amountPayable;
  int? orderID;
  String? refID;

 




  var publicKey = 'pk_test_900f6286d49dd3d323d4b8e4530501fd060356d6';
  final plugin = PaystackPlugin();

  String _getReference() {
    return '${DateTime.now().millisecondsSinceEpoch}';
  }
  
  _initiatePayment() async{
    showInputDialog(context);
  }

  
    _confirmOrder(context) async{
          result = await Connectivity().checkConnectivity();
          if (result == ConnectivityResult.mobile || result == ConnectivityResult.wifi) {
                  setState(() {
                        isLoading = true;
                      });
                      isLoading
                          ? showLoadingDialog(context)
                          : Navigator.of(context, rootNavigator: true).pop('dialog');
                      Timer(Duration(seconds: 3), () {
                         setState(() {
                          isLoading = false;
                        });
                        !isLoading
                            ? Navigator.of(context, rootNavigator: true).pop('dialog')
                            : showLoadingDialog(context);
                        //CallBackFunction Here
                        _initiateUserTransaction();
                       
                      });
                      
                     
                        //Success Page Call Here
            }else{
                showInternetError(context);
            }
  }

  _initiateUserTransaction() async {
          final response =
            await http.post(Uri.parse('https://teamcoded.com.ng/crypto.php'), body: {
            "request": "INITIATE TRANSACTION",
            "user": userID.toString(),
            "BTC_amount": widget.sellBTC.toString(),
            "NGN_amount": widget.sellAmount.toString(),
            "transaction_type": 'SellBTC', 
            "orderID": orderID.toString()
      });

      if (response.statusCode == 200) {
          _initiatePayment();
      }
      
     
  }


  _updateUserTransaction(refID, orderID, acoountNo) async {
          final response =
            await http.post(Uri.parse('https://teamcoded.com.ng/crypto.php'), body: {
            "request": "UPDATE TRANSACTION",
            "user": userID.toString(),
            "BTC_amount": widget.sellBTC.toString(),
            "NGN_amount": widget.sellAmount.toString(),
            "transaction_type": 'SellBTC', 
            "ref": refID.toString(),
            "orderID": orderID.toString(),
            "accountNo": acoountNo.toString()
      });

      if (response.statusCode == 200) {
         setState(() {
        isLoading = false;
      });
      !isLoading
          ? Navigator.of(context, rootNavigator: true).pop('dialog')
          : showLoadingDialog(context);
          Navigator.push(context, MaterialPageRoute(builder: (context) => SuccessSell(sellAmount: widget.sellAmount, sellBTC: widget.sellBTC, ref: refID,)));
      }
      
     
  }

 
getData() {
      setState(() {
      userID = Constants.sharedPref!.getString("user");
      });
}


@override
  void initState() {
    plugin.initialize(publicKey: publicKey);
    getData();
    amountPayable = double.parse(widget.sellAmount).round();
    orderID = random.nextInt(1000000000);
    refID = _getReference();
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: singleAppBar(title: 'Review', context: context,),
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child: Form(
            key: formKey,
            child: ListView(
            children: [
             Container(
              height: screenHeight(context)*0.30,
              width: screenWidth(context),
              decoration: BoxDecoration(
                color:  Constants.kPrimaryColor2
              ),
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('img/test.png', width: 120, height: 100,),
                  YMargin(1.0),
                  Text(
                        'Sell BTC ${widget.sellBTC}',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ),
                      YMargin(4.0),
                      Text(
                        'At NGN ${widget.sellAmount}',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ),
                ],
              ),
             ),
             
              Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 40.0, 8.0, 30.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                               Text(
                                'You Sell',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                        Padding(padding: EdgeInsets.all(1.0)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                               Text(
                                ' BTC ${widget.sellBTC}',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 10.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                               Text(
                                'Service Charges',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                        Padding(padding: EdgeInsets.all(10.0)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                               Text(
                                'NGN 26.00',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

               Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 20.0, 8.0, 30.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                               Text(
                                'You recieve',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                        Padding(padding: EdgeInsets.all(10.0)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                               Text(
                                'NGN ${double.parse(widget.sellAmount) - 50}',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

               Padding(
                 padding: const EdgeInsets.fromLTRB(8.0, 20.0, 8.0, 10.0),
                 // ignore: deprecated_member_use
                 child: FlatButton(
                    color: Constants.kPrimaryColor.withOpacity(0.7),
                    child: Text(
                        'CONFIRM',
                        style: TextStyle(fontSize: 14),
                    ),
                    shape: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white, width: 1),
                        borderRadius: BorderRadius.circular(3.0),
                    ),
                    padding: EdgeInsets.all(18),
                    textColor: Colors.white,
                    onPressed: () {
                      _confirmOrder(context) ;
                        //  Future.delayed(Duration.zero, () async{
                        // await Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                        // });
                    },
                  ),
               ),
                      
            ],
          ),
          ),
        ),
    );
  }

  void showInputDialog(context) {
    // flutter defined function
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              
              Center( child: new Text("Enter beneficiary account number", style: TextStyle(fontSize: 14),)),
              YMargin(10),
              TextFormField(
                style: TextStyle(
                    fontSize: 16, color: Colors.black54),
                    textCapitalization: TextCapitalization.sentences,
                    keyboardType: TextInputType.number,
                    autofocus: true,
                decoration: InputDecoration(
                  labelText: 'Account Number',
                  hintStyle: TextStyle(fontSize: 14),
                  contentPadding: const EdgeInsets.all(10),
                  filled: true,
                  fillColor: Colors.white,
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                    color: Colors.grey[300]!,
                  )),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                    color: Colors.grey[300]!,
                  )),
                  suffix: Icon(Icons.money,),
                ),
                // validator: (val) =>
                //     val!.length == 0 ? 'This field is required' : null,
                controller: accountController,
                // onSaved: (val) => naira = val,
                // onChanged: (value) => _calculateBTC(value),
              ),
              YMargin(15),
               Padding(
                 padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                 // ignore: deprecated_member_use
                 child: FlatButton(
                    color: Constants.kPrimaryColor.withOpacity(0.7),
                    child: Text(
                        'PROCEED',
                        style: TextStyle(fontSize: 14),
                    ),
                    shape: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white, width: 1),
                        borderRadius: BorderRadius.circular(3.0),
                    ),
                    padding: EdgeInsets.all(15),
                    textColor: Colors.white,
                    onPressed: () {
                      var acoountNo = accountController.text;
                        setState(() {
                        isLoading = true;
                      });
                      isLoading
                          ? showLoadingDialog(context)
                          : Navigator.of(context, rootNavigator: true).pop('dialog');
                      _updateUserTransaction(refID, orderID, acoountNo);
                    },
                  ),
               ),
            ],
          ),
        );
      },
    );
  }
}