import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/buy.dart';
import 'package:naija_coin/screens/user/review.dart';
import 'package:naija_coin/screens/user/sell.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:naija_coin/widgets/users_widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;


class Wallet extends StatefulWidget {
  const Wallet({ Key? key }) : super(key: key);
  @override
  _WalletState createState() => _WalletState();
}

class _WalletState extends State<Wallet> {

  final formKey = new GlobalKey<FormState>();

  final TextEditingController btcController = new TextEditingController();
   

  String? naira;
  String? btc;
  var result;
  List? userData;
  List? transactionData;

  var spinkit = SpinKitDualRing(
      color: Colors.white,
      size: 15.0,
    );
   
  final double oneBTC = 17153567.09;

    _validateForm(context) async{
      if (formKey.currentState!.validate()) {

          result = await Connectivity().checkConnectivity();

          if (result == ConnectivityResult.mobile || result == ConnectivityResult.wifi) {
                formKey.currentState!.save();
                  if (btc == null || double.parse(btc!) < 0.000029) {
                    showBitcoinError(context);
                  }else if(double.parse(btc!) > double.parse(userData![0]["BTC_balance"])){
                    showBitcoinInsufficientError(context);
                  }else{
                     Navigator.push(context, MaterialPageRoute(builder: (context) => Review(sellAmount: naira, sellBTC: btc,)));
                  }
            }else{
                formKey.currentState!.save();
                showInternetError(context);
            }
      
    }
  }


  String format(double n) {
    return n.toStringAsFixed(n.truncateToDouble() == n ? 0 : 2);
  }

  _calculateBTC(btc){
     var nairaAmount =   double.parse(btc) * oneBTC;
     setState(() {
       naira =  nairaAmount.toStringAsFixed(2).toString();
     });
  }

   Future<List> _fetchUserData() async {
        final response =
        await http.post(Uri.parse("https://teamcoded.com.ng/crypto.php"), body: {
        "request": "FETCH USER DETAILS BY ID",
        "user" : userID,
          });
          var convertDateToJson = jsonDecode(response.body);
        setState(() {
        userData = convertDateToJson;
      });
      return userData!;
      }

getData() {
      setState(() {
      userID = Constants.sharedPref!.getString("user");
      });
}


Future<List> _fetchTransactionData() async {
        final response =
        await http.post(Uri.parse("https://teamcoded.com.ng/crypto.php"), body: {
        "request": "FETCH USER TRANSACTIONS",
        "user" : userID,
          });
          var convertDateToJson = jsonDecode(response.body);
        setState(() {
        transactionData = convertDateToJson;
      });
      return transactionData!;
      }

      
@override
  void initState() {
    getData();
    _fetchUserData();
    _fetchTransactionData();
    super.initState();
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: singleAppBar(title: 'Wallet', context: context,),
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child:
          ListView(
          children: [
           Container(
            height: screenHeight(context)*0.15,
            width: screenWidth(context),
            decoration: BoxDecoration(
              color:  Constants.kPrimaryColor
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                userData !=null ?  
                Text(
                      'BTC ${double.parse(userData![0]["BTC_balance"])  }',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.robotoMono(textStyle:
                        TextStyle(
                          color: Constants.kPrimaryColor2,
                          fontSize: 25.0,
                          fontWeight: FontWeight.w800),
                          
                      )
                    )  : Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                      Text(
                      'BTC  ',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.robotoMono(textStyle:
                        TextStyle(
                          color: Constants.kPrimaryColor2,
                          fontSize: 25.0,
                          fontWeight: FontWeight.w800),
                          
                      )
                    ) ,
                      spinkit,
                    ],),
                    YMargin(4.0),
                    userData !=null ? Text(
                      '-NGN ${ userData![0]["NGN_balance"] }',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.robotoMono(textStyle:
                        TextStyle(
                          color: Constants.kPrimaryColor2,
                          fontSize: 18.0,
                          fontWeight: FontWeight.w800),
                          
                      )
                    ) :  Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                      Text(
                      '-NGN  ',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.robotoMono(textStyle:
                        TextStyle(
                          color: Constants.kPrimaryColor2,
                          fontSize: 25.0,
                          fontWeight: FontWeight.w800),
                          
                      )
                    ) ,
                      spinkit,
                    ],),
              ],
            ),
           ),

            Padding(
              padding: const EdgeInsets.fromLTRB(5.0, 15.0, 5.0, 20.0),
              child: GridView.count(
                        crossAxisCount: 2,
                        childAspectRatio: 1.2,
                        padding: const EdgeInsets.all(0.0),
                        mainAxisSpacing: 4.0,
                        crossAxisSpacing: 4.0,
                        shrinkWrap: true,
                        primary: false,
                        children: [
                           chooseMenu(
                            context, 
                            "BUY", 
                             Icons.download,  
                            () {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Buy()));
                            },
                            Colors.teal[600]!,
                            ),  
                            chooseMenu(
                            context, 
                            "SELL", 
                            Icons.upload,
                            () {
                               Navigator.push(context, MaterialPageRoute(builder: (context) => Sell()));
                            },
                            Colors.deepOrange[700]!
                            ),
                        ] 
              ),
            ),
           
  
             Padding(
               padding: const EdgeInsets.fromLTRB(5.0, 0.0, 5.0, 2.0),
               child: Text(
                 'TRANSACTION HISTORY',
                 style: GoogleFonts.sourceSansPro(
                   textStyle: TextStyle(fontSize: 14.0, color: Colors.black54, fontWeight: FontWeight.w600),
                 ),
               ),
             ),
             YMargin(5),
           Padding(
             padding: const EdgeInsets.fromLTRB(5.0, 0.0, 5.0, 0.0),
             child: Container(
               height: screenHeight(context, percent: 0.4),
               width: screenWidth(context),
               color: Colors.white,
               child:
               transactionData != null ? ListView.builder(
               shrinkWrap: true,
                itemCount: transactionData == null ? 0 : transactionData!.length,
               itemBuilder: (BuildContext context, int index) {
                     return transactionCard(
                       title: transactionData![index]["Transaction_type"] == "BuyBTC" ? "Buy BTC" : "Sell BTC",
                       transactionId: transactionData![index]["Transaction_type"] == "BuyBTC" ? "BTC "+transactionData![index]["NGN_amount"] : "NGN "+transactionData![index]["BTC_amount"],
                       price: transactionData![index]["Transaction_type"] == "BuyBTC" ? "BTC "+transactionData![index]["BTC_amount"] : "NGN "+transactionData![index]["NGN_amount"],
                       date: transactionData![index]["Transaction_date"],
                     ); 
               } 
               ) : Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(strokeWidth: 2,),
                      YMargin(5),
                       Text(
                        'Loading...',
                        style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: 'Quando',
                          color: Colors.black54,
                        ),
                      )
                    ],
                ),
             ),
           ),
                    
          ],
          ),
      ),
    );
  }
}