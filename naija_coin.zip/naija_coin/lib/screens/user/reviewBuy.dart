import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:naija_coin/screens/user/successBuy.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:naija_coin/widgets/users_widget.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
import 'package:connectivity/connectivity.dart';
import 'package:http/http.dart' as http;
import 'dart:math';


class ReviewBuy extends StatefulWidget {
  const ReviewBuy({ Key? key, this.buyBTC, this.buyAmount}) : super(key: key);
  final buyBTC;
  final buyAmount;
  @override
  _ReviewBuyState createState() => _ReviewBuyState();
}

class _ReviewBuyState extends State<ReviewBuy> {

  final formKey = new GlobalKey<FormState>();
  Random random = new Random();
  final TextEditingController nairaController = new TextEditingController();
   

 bool isLoading = false;
  var result;
  int? amountPayable;
  int? orderID;
  String? refID;




  var publicKey = 'pk_test_900f6286d49dd3d323d4b8e4530501fd060356d6';
  final plugin = PaystackPlugin();

  String _getReference() {
    return '${DateTime.now().millisecondsSinceEpoch}';
  }
  
  _initiatePayment() async{
    Charge charge = Charge()
       ..amount = amountPayable!  * 100
       ..reference =  refID
        // or ..accessCode = _getAccessCodeFrmInitialization()
       ..email = 'adammusa89@email.com';
        CheckoutResponse response = await plugin.checkout(
          context,
          method: CheckoutMethod.card, // Defaults to CheckoutMethod.selectable
          charge: charge,
        );

        if (response.status) {
          _updateUserTransaction(refID, orderID);
        }
  }

  
    _confirmOrder(context) async{
          result = await Connectivity().checkConnectivity();
          if (result == ConnectivityResult.mobile || result == ConnectivityResult.wifi) {
                  setState(() {
                        isLoading = true;
                      });
                      isLoading
                          ? showLoadingDialog(context)
                          : Navigator.of(context, rootNavigator: true).pop('dialog');
                      Timer(Duration(seconds: 3), () {
                         setState(() {
                          isLoading = false;
                        });
                        !isLoading
                            ? Navigator.of(context, rootNavigator: true).pop('dialog')
                            : showLoadingDialog(context);
                        //CallBackFunction Here
                        _initiateUserTransaction();
                       
                      });
                      
                     
                        //Success Page Call Here
            }else{
                showInternetError(context);
            }
  }

  _initiateUserTransaction() async {
          final response =
            await http.post(Uri.parse('https://teamcoded.com.ng/crypto.php'), body: {
            "request": "INITIATE TRANSACTION",
            "user": userID.toString(),
            "BTC_amount": widget.buyBTC.toString(),
            "NGN_amount": widget.buyAmount.toString(),
            "transaction_type": 'BuyBTC', 
            "orderID": orderID.toString()
      });

      if (response.statusCode == 200) {
        print(response.body.toString());
          _initiatePayment();
      } 
      
     
  }


  _updateUserTransaction(refID, orderID) async {
          final response =
            await http.post(Uri.parse('https://teamcoded.com.ng/crypto.php'), body: {
            "request": "UPDATE TRANSACTION",
            "user": userID.toString(),
            "BTC_amount": widget.buyBTC.toString(),
            "NGN_amount": widget.buyAmount.toString(),
            "transaction_type": 'BuyBTC', 
            "ref": refID.toString(),
            "orderID": orderID.toString()
      });

      if (response.statusCode == 200) {
        print(response.body.toString());
          Navigator.push(context, MaterialPageRoute(builder: (context) => SuccessBuy(buyAmount: widget.buyAmount, buyBTC: widget.buyBTC, ref: refID,)));
      }
      
     
  }

 
getData() {
      setState(() {
      userID = Constants.sharedPref!.getString("user");
      });
}


@override
  void initState() {
    plugin.initialize(publicKey: publicKey);
    getData();
    amountPayable = int.parse(widget.buyAmount) + 50;
    orderID = random.nextInt(1000000000);
    refID = _getReference();
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: singleAppBar(title: 'Review', context: context,),
      body: Container(
          height: screenHeight(context),
          width: screenWidth(context),
          child: Form(
            key: formKey,
            child: ListView(
            children: [
             Container(
              height: screenHeight(context)*0.30,
              width: screenWidth(context),
              decoration: BoxDecoration(
                color:  Constants.kPrimaryColor2
              ),
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('img/test.png', width: 120, height: 100,),
                  YMargin(1.0),
                  Text(
                        'Buy BTC ${widget.buyBTC}',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor,
                            fontSize: 25.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ),
                      YMargin(4.0),
                      Text(
                        'At NGN ${widget.buyAmount}',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.robotoMono(textStyle:
                          TextStyle(
                            color: Constants.kPrimaryColor,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w800),
                            
                        )
                      ),
                ],
              ),
             ),
             
              Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 40.0, 8.0, 30.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                               Text(
                                'You buy',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                        Padding(padding: EdgeInsets.all(1.0)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                               Text(
                                ' BTC ${widget.buyBTC}',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 10.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                               Text(
                                'Service Charges',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                        Padding(padding: EdgeInsets.all(10.0)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                               Text(
                                'NGN 50.00',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

               Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 20.0, 8.0, 30.0),
                child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                               Text(
                                'Amount payable',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                        Padding(padding: EdgeInsets.all(10.0)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            
                               Text(
                                'NGN ${double.parse(widget.buyAmount) + 50}',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.robotoMono(textStyle:
                                  TextStyle(
                                    color: Constants.kPrimaryColor,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w800),
                                    
                                )
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),

               Padding(
                 padding: const EdgeInsets.fromLTRB(8.0, 20.0, 8.0, 10.0),
                 // ignore: deprecated_member_use
                 child: FlatButton(
                    color: Constants.kPrimaryColor.withOpacity(0.7),
                    child: Text(
                        'CONFIRM',
                        style: TextStyle(fontSize: 14),
                    ),
                    shape: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white, width: 1),
                        borderRadius: BorderRadius.circular(3.0),
                    ),
                    padding: EdgeInsets.all(18),
                    textColor: Colors.white,
                    onPressed: () {
                      _confirmOrder(context) ;
                        //  Future.delayed(Duration.zero, () async{
                        // await Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                        // });
                    },
                  ),
               ),
                      
            ],
          ),
          ),
        ),
    );
  }
}