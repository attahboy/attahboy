import 'package:flutter/material.dart';
import 'package:naija_coin/screens/home/splashscreen.dart';
import 'package:naija_coin/util/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future  main() async{
  WidgetsFlutterBinding.ensureInitialized();
  Constants.sharedPref = await SharedPreferences.getInstance();
  runApp(MyApp());
  
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Naija Coin',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: SplashScreen(),
    );
  }
}

